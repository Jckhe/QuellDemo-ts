# QuellDemo
Demo for Quell written in React utilizing Material UI.



Contains:
-Backend serving connected to MongoDB to be used for querying and testing




-Frontend created with React/Typescript and utilizes Material UI.
